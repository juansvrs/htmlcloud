import pika
import json

def lambda_handler(event, context):
    # Conexión a RabbitMQ en EC2
    credentials = pika.PlainCredentials('wider', 'wider')
    connection = pika.BlockingConnection(pika.ConnectionParameters('100.26.179.81', port, '/', credentials))
    channel = connection.channel()

    # Declarar la cola
    channel.queue_declare(queue='prueba', durable=True)

    # Función para procesar el mensaje
    def callback(ch, method, properties, body):
        message = json.loads(body)
        print("Mensaje recibido:", message)
        # Aquí puedes agregar la lógica para procesar el mensaje

    # Consumir mensajes
    channel.basic_consume(queue='prueba', on_message_callback=callback, auto_ack=True)

    print('Esperando mensajes...')
    channel.start_consuming()

    return {
        'statusCode': 200,
        'body': json.dumps('Función Lambda ejecutada correctamente')
    }
