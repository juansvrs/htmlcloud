import pika
import json

def lambda_handler(event, context):
    # Conexión a RabbitMQ
    connection = pika.BlockingConnection(pika.ConnectionParameters('direccion del servidor sin http', 5672, '/', pika.PlainCredentials('user', 'pass')))
    channel = connection.channel()

    # Declarar la cola
    channel.queue_declare(queue='prueba', durable=True)

    # Enviar el mensaje
    message = json.dumps(event)  # Convierte el evento a JSON
    channel.basic_publish(exchange='', routing_key='prueba', body=message)

    print("Mensaje enviado:", message)

    # Cerrar la conexión
    connection.close()
